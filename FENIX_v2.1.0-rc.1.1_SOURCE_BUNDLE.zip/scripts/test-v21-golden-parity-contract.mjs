import assert from 'node:assert/strict'
import fs from 'node:fs'

const read = (path) => fs.readFileSync(path, 'utf8')
const ds = read('src/styles/design-system.css')
const app = read('src/styles/app.css')
const today = read('src/features/today/today.css')
const training = read('src/features/training/training.css')
const nutrition = read('src/features/nutrition/nutrition-vnext.css')
const libraryCss = read('src/features/nutrition/nutrition-library-vnext.css')
const libraryTsx = read('src/features/nutrition/NutritionLibrary.tsx')
const progress = read('src/features/progress/progress.css')
const settings = read('src/features/settings/settings.css')
const visual = read('qa/v2.1/e2e/visual.spec.ts')
const helpers = read('qa/v2.1/e2e/helpers.ts')

for (const legacy of ['final-v1.css', 'mobile-density.css', 'render-parity.css', 'visual-polish.css', 'final-v2.css']) {
  assert.ok(!fs.existsSync(`src/styles/${legacy}`), `Golden parity must not resurrect tactical override layer: ${legacy}`)
}

assert.match(ds, /--fenix-tap:44px/, '44px interaction floor token must remain canonical')
assert.match(ds, /@media \(max-width:600px\)[\s\S]*--fenix-gutter:8px/, 'iPhone Golden gutter must be consolidated in Design System')
assert.match(ds, /\.ds-sheet\{width:100%;height:100dvh;max-height:100dvh;border:0;border-radius:0;/, 'mobile Sheet must render as full-screen Golden detail/editor surface')
assert.match(ds, /\.ds-segmented button\{min-height:44px/, 'segmented controls must retain 44px tap floor')
assert.match(app, /\.fenix-navigation button\{min-height:48px[\s\S]*font-size:8\.5px/, 'bottom navigation must use compact Golden geometry')

assert.match(today, /\.today-hero--integrated\{grid-template-columns:minmax\(0,1fr\)/, 'Hoy progress and AHORA must occupy separate full-width rows')
assert.match(today, /\.today-dashboard-grid\{display:grid;grid-template-columns:repeat\(3,minmax\(0,1fr\)\)/, 'Hoy must expose three compact module cards')
assert.match(today, /\.today-start-card\{grid-template-columns:58px minmax\(0,1fr\)/, 'Day 0 start surface must remain compact')

assert.match(training, /\.training-page>\.ds-app-header,[\s\S]*width:100%;max-width:none/, 'Training Golden surfaces must not retain the 32px inset constraint')
assert.match(training, /\.training-exercise-catalog--grid\{grid-template-columns:1fr;gap:4px\}/, 'Training exercise catalog must be a compact single-column list')
assert.match(training, /\.training-catalog-card--button\{display:grid;grid-template-columns:78px minmax\(0,1fr\)/, 'Training exercise list card must reserve compact media + copy columns')
assert.match(training, /\.training-routine-detail-v21__hero\{grid-template-columns:minmax\(0,1fr\) 112px/, 'routine detail hero must keep muscle media bounded')

assert.match(nutrition, /\.nutrition-vnext-shell>\.ds-app-header,[\s\S]*width:100%;max-width:none/, 'Nutrition Golden surfaces must not retain the 32px inset constraint')
assert.match(nutrition, /\.nutrition-vnext-macros\{padding:9px\}/, 'Nutrition daily macro surface must use compact Golden density')
assert.match(libraryCss, /\.nutrition-library-vnext \.nutrition-library-hero\{display:none\}/, 'embedded Recipes/Compra must not duplicate the main Nutrition hero')
assert.match(libraryCss, /:has\(\.nutrition-detail__header\)>\.ds-app-header/, 'recipe detail must own the full-screen mobile surface')
assert.match(libraryTsx, /<RecipeVisual recipe=\{item\.recipe\} name=\{item\.recipe\.name\} variant="hero" \/>/, 'recipe detail must include the approved visual hero')

assert.match(progress, /\.progress-metric-card\{min-height:108px;padding:8px/, 'Progress summary cards must use compact Golden geometry')
assert.match(progress, /\.progress-weight-hero,[\s\S]*padding:8px;margin-bottom:5px/, 'Progress detail surfaces must be compact')
assert.match(settings, /\.settings-row,\.settings-action-row\{min-height:58px/, 'Settings list rows must preserve compact Golden rhythm')

assert.match(visual, /GOLDEN_REFERENCE_TIME = new Date\('2026-09-03T07:41:00\+02:00'\)/, 'visual matrix must use the Design Freeze reference date')
assert.match(visual, /seedGoldenVisualFacts\(page\)/, 'visual matrix must use deterministic synthetic Golden facts')
assert.match(helpers, /export async function seedGoldenVisualFacts/, 'Golden fixture must be QA-only and explicit')
assert.match(helpers, /visual-weight-\$\{date\}/, 'Golden fixture must include deterministic weight history')
assert.match(helpers, /visual-session-/, 'Golden fixture must include deterministic Training history')
assert.match(helpers, /visual-routine-/, 'Golden fixture must include deterministic adherence history')

console.log('FÉNIX v2.1 presentation source guards: PASS (not Golden parity; image comparison remains mandatory)')
