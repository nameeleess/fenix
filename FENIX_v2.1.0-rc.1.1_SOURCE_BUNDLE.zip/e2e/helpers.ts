import { expect, type Page } from '@playwright/test'
import fs from 'node:fs'
import path from 'node:path'

export const SCREENSHOT_DIR = path.resolve('qa/v2.1/evidence/screenshots')

const visualOverflowFailures: string[] = []

export function resetVisualStateChecks() {
  visualOverflowFailures.length = 0
}

export function assertVisualStateChecks() {
  expect(visualOverflowFailures, `Visual overflow failures:\n${visualOverflowFailures.join('\n')}`).toEqual([])
}

export async function openApp(page: Page) {
  const pageErrors: string[] = []
  const consoleErrors: string[] = []

  page.on('pageerror', (error) => {
    pageErrors.push(error.stack ?? error.message)
  })
  page.on('console', (message) => {
    if (message.type() === 'error') consoleErrors.push(message.text())
  })

  const response = await page.goto('/', { waitUntil: 'domcontentloaded' })
  if (!response || !response.ok()) {
    throw new Error(`FÉNIX preview navigation failed: status=${response?.status() ?? 'no-response'} url=${page.url()}`)
  }

  const mainNavigation = page.getByRole('navigation', { name: 'Navegación principal' })

  try {
    await expect(mainNavigation).toBeVisible({ timeout: 15_000 })
    await expect(page.locator('.fenix-route-loading')).toHaveCount(0, { timeout: 15_000 })
    await expect(page.getByRole('heading', { name: 'Hoy', exact: true })).toBeVisible({ timeout: 15_000 })

    // Catch reload/update races: the shell must remain stable briefly after Today is ready.
    await page.waitForTimeout(300)
    await expect(mainNavigation).toBeVisible()
    await expect(page.getByRole('heading', { name: 'Hoy', exact: true })).toBeVisible()
  } catch (error) {
    const diagnostics = await page.evaluate(async () => {
      let registrations: string[] = []
      try {
        if ('serviceWorker' in navigator) {
          registrations = (await navigator.serviceWorker.getRegistrations()).map((item) => item.scope)
        }
      } catch {
        registrations = ['<service-worker-inspection-failed>']
      }

      return {
        url: location.href,
        readyState: document.readyState,
        title: document.title,
        bodyText: document.body?.innerText.slice(0, 2400) ?? '',
        hasController: 'serviceWorker' in navigator ? Boolean(navigator.serviceWorker.controller) : false,
        registrations,
      }
    })

    throw new Error([
      `FÉNIX browser boot did not stabilize: ${error instanceof Error ? error.message : String(error)}`,
      `diagnostics=${JSON.stringify(diagnostics)}`,
      `pageErrors=${JSON.stringify(pageErrors)}`,
      `consoleErrors=${JSON.stringify(consoleErrors)}`,
    ].join('\n'), { cause: error })
  }
}

export async function mainNav(page: Page, name: 'Hoy' | 'Training' | 'Nutrition' | 'Progreso') {
  const nav = page.getByRole('navigation', { name: 'Navegación principal' })
  const button = nav.getByRole('button', { name, exact: true })
  await expect(nav).toBeVisible()
  await button.click()
  await expect(button).toHaveAttribute('aria-current', 'page')
  await expect(page.getByRole('heading', { name, exact: true })).toBeVisible()
}

export async function segmented(page: Page, navName: string, name: string) {
  const nav = page.getByRole('navigation', { name: navName })
  const button = nav.getByRole('button', { name, exact: true })
  await expect(nav).toBeVisible()
  await button.click()
  await expect(button).toHaveAttribute('aria-current', 'page')
}

export async function screenshotState(page: Page, fileName: string) {
  fs.mkdirSync(SCREENSHOT_DIR, { recursive: true })
  await expect(page.locator('body')).toBeVisible()
  const overflow = await page.evaluate(() => {
    const viewportWidth = document.documentElement.clientWidth
    const pixels = Math.max(0, document.documentElement.scrollWidth - viewportWidth)
    const offenders = Array.from(document.querySelectorAll<HTMLElement>('body *'))
      .map((element) => {
        const rect = element.getBoundingClientRect()
        return {
          tag: element.tagName.toLowerCase(),
          className: typeof element.className === 'string' ? element.className : '',
          left: Math.round(rect.left),
          right: Math.round(rect.right),
          width: Math.round(rect.width),
        }
      })
      .filter((item) => item.right > viewportWidth + 2 || item.left < -2)
      .sort((a, b) => Math.max(b.right - viewportWidth, -b.left) - Math.max(a.right - viewportWidth, -a.left))
      .slice(0, 8)
    return { pixels, offenders }
  })
  if (overflow.pixels > 2) {
    visualOverflowFailures.push(`${fileName}: horizontal overflow=${overflow.pixels}px; offenders=${JSON.stringify(overflow.offenders)}`)
  }
  await page.screenshot({ path: path.join(SCREENSHOT_DIR, fileName), fullPage: false, animations: 'disabled' })
}

export async function closeTopSheet(page: Page) {
  const dialog = page.getByRole('dialog').last()
  if (await dialog.count()) {
    const close = dialog.getByRole('button', { name: 'Cerrar' }).first()
    if (await close.count()) await close.click()
  }
}


export async function seedGoldenVisualFacts(page: Page) {
  await page.evaluate(async () => {
    const request = indexedDB.open('fenix-db')
    const database = await new Promise<IDBDatabase>((resolve, reject) => {
      request.onerror = () => reject(request.error)
      request.onsuccess = () => resolve(request.result)
    })

    const stores = [
      'weightEntries',
      'bodyMeasurements',
      'progressFeaturedExercises',
      'plannedWorkoutSessions',
      'workoutSessions',
      'workoutSessionExercises',
      'exerciseSets',
      'dailyRoutines',
      'dailyRoutineTasks',
      'workoutTemplates',
      'exercises',
      'dailyRoutineTemplates',
    ]
    const tx = database.transaction(stores, 'readwrite')
    const getAll = <T,>(name: string) => new Promise<T[]>((resolve, reject) => {
      const op = tx.objectStore(name).getAll()
      op.onerror = () => reject(op.error)
      op.onsuccess = () => resolve(op.result as T[])
    })
    const put = (name: string, value: unknown) => tx.objectStore(name).put(value)
    const stamp = (id: string, at: string) => ({
      id, createdAt: at, updatedAt: at, deletedAt: null, version: 1,
    })

    const weightSeries = [
      ['2026-08-10', 70.1], ['2026-08-13', 69.6], ['2026-08-17', 68.8],
      ['2026-08-20', 68.1], ['2026-08-24', 67.3], ['2026-08-27', 66.9],
      ['2026-08-31', 66.4], ['2026-09-01', 66.1], ['2026-09-03', 66.2],
    ] as const
    for (const [date, weightKg] of weightSeries) {
      const at = `${date}T05:30:00.000Z`
      put('weightEntries', {
        ...stamp(`visual-weight-${date}`, at), date, recordedAt: at, weightKg,
        comparable: true, exceptionNote: null, notes: null, bodyFatPercent: null,
        fatMassKg: null, muscleMassKg: null, biaSource: null,
      })
    }

    const measures = [
      ['2026-07-03', 92.1, 33.4, 33.2],
      ['2026-08-03', 89.9, 34.0, 33.9],
      ['2026-09-03', 87.8, 34.6, 34.5],
    ] as const
    for (const [date, waistCm, rightArmCm, leftArmCm] of measures) {
      const at = `${date}T05:40:00.000Z`
      put('bodyMeasurements', {
        ...stamp(`visual-measure-${date}`, at), date, recordedAt: at, waistCm,
        rightArmCm, leftArmCm, notes: null,
      })
    }

    const exercises = await getAll<{ id: string; name: string; deletedAt: string | null }>('exercises')
    // Isolated test facts, not claimed Golden values. Do not assign barbell loads
    // to mobility exercises merely because IndexedDB returns them first.
    const strengthIds = ['ex-bench-press', 'ex-incline-dumbbell-press', 'ex-seated-cable-row', 'ex-rdl', 'ex-ez-bar-curl']
    const activeExercises = strengthIds.map(id => exercises.find(item => item.id === id && item.deletedAt === null)).filter((item): item is typeof exercises[number] => Boolean(item))
    activeExercises.slice(0, 5).forEach((exercise, index) => {
      put('progressFeaturedExercises', {
        ...stamp(`visual-featured-${index + 1}`, '2026-09-03T05:45:00.000Z'),
        exerciseId: exercise.id, order: index + 1,
      })
    })

    const templates = await getAll<{ id: string; name: string; isFormalStrength?: boolean; deletedAt: string | null }>('workoutTemplates')
    const formal = templates.filter((item) => item.deletedAt === null && item.isFormalStrength).slice(0, 4)
    const sessionDates = ['2026-08-21', '2026-08-24', '2026-08-25', '2026-08-28', '2026-08-31', '2026-09-01']
    sessionDates.forEach((date, sessionIndex) => {
      const template = formal[sessionIndex % Math.max(1, formal.length)]
      if (!template) return
      const plannedId = `visual-planned-${date}`
      const sessionId = `visual-session-${date}`
      const startedAt = `${date}T06:00:00.000Z`
      const endedAt = `${date}T07:00:00.000Z`
      put('plannedWorkoutSessions', {
        ...stamp(plannedId, startedAt), workoutTemplateId: template.id, templateName: template.name,
        originalScheduledDate: date, scheduledDate: date, status: 'completed',
        executionSessionId: sessionId, isFormalStrength: true, isExtra: false,
        estimatedDurationMinutes: 60, rescheduleCount: 0, resolvedAt: endedAt, notes: null,
      })
      put('workoutSessions', {
        ...stamp(sessionId, startedAt), workoutTemplateId: template.id, templateName: template.name,
        status: 'completed', plannedWorkoutId: plannedId, startedAt, completedAt: endedAt,
        endedAt, notes: null,
      })
      activeExercises.slice(0, 4).forEach((exercise, exerciseIndex) => {
        const sessionExerciseId = `visual-session-ex-${sessionIndex}-${exerciseIndex}`
        put('workoutSessionExercises', {
          ...stamp(sessionExerciseId, startedAt), workoutSessionId: sessionId,
          sourceTemplateExerciseId: null, exerciseId: exercise.id, exerciseName: exercise.name,
          order: exerciseIndex + 1, targetSets: 3, minReps: 8, maxReps: 12,
          targetRirMin: 1, targetRirMax: 2, restSeconds: 120,
          substitutedFromExerciseId: null, notes: null, targetSeconds: null,
        })
        for (let setIndex = 1; setIndex <= 3; setIndex += 1) {
          put('exerciseSets', {
            ...stamp(`visual-set-${sessionIndex}-${exerciseIndex}-${setIndex}`, endedAt),
            workoutSessionId: sessionId, workoutSessionExerciseId: sessionExerciseId,
            exerciseId: exercise.id, exerciseName: exercise.name, order: setIndex, setType: 'working',
            weight: 20 + exerciseIndex * 7.5, reps: 8 + ((sessionIndex + setIndex) % 4),
            rir: 1 + (setIndex % 2), completedAt: endedAt,
          })
        }
      })
    })

    const routineTemplates = await getAll<{ id: string; deletedAt: string | null }>('dailyRoutineTemplates')
    const routineTemplate = routineTemplates.find((item) => item.deletedAt === null)
    const routineDates = ['2026-08-28', '2026-08-29', '2026-08-30', '2026-08-31', '2026-09-01', '2026-09-02']
    if (routineTemplate) {
      routineDates.forEach((date, dayIndex) => {
        const routineId = `visual-routine-${date}`
        const at = `${date}T05:00:00.000Z`
        put('dailyRoutines', {
          ...stamp(routineId, at), date, templateId: routineTemplate.id, startedAt: at,
        })
        ;['Higiene', 'Movilidad', 'Preparar día', 'Cierre'].forEach((title, taskIndex) => {
          const status = (dayIndex + taskIndex) % 7 === 0 ? 'skipped' : 'completed'
          put('dailyRoutineTasks', {
            ...stamp(`visual-task-${date}-${taskIndex}`, at), dailyRoutineId: routineId, date,
            sourceTemplateItemId: null, block: taskIndex < 2 ? 'morning' : 'night',
            order: (taskIndex + 1) * 10, kind: 'template', title, description: null,
            applicability: 'always', status, completedAt: status === 'completed' ? at : null,
            statusChangedAt: at, targetTime: null, latestTime: null, timingApplies: true,
          })
        })
      })
    }

    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve()
      tx.onerror = () => reject(tx.error)
      tx.onabort = () => reject(tx.error ?? new Error('Golden visual fixture transaction aborted'))
    })
    database.close()
  })
}

export async function readStore<T = Record<string, unknown>>(page: Page, storeName: string): Promise<T[]> {
  return page.evaluate(async (name) => {
    const request = indexedDB.open('fenix-db')
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      request.onerror = () => reject(request.error)
      request.onsuccess = () => resolve(request.result)
    })
    try {
      const tx = db.transaction(name, 'readonly')
      const store = tx.objectStore(name)
      const values = await new Promise<unknown[]>((resolve, reject) => {
        const all = store.getAll()
        all.onerror = () => reject(all.error)
        all.onsuccess = () => resolve(all.result)
      })
      await new Promise<void>((resolve, reject) => {
        tx.oncomplete = () => resolve()
        tx.onerror = () => reject(tx.error)
        tx.onabort = () => reject(tx.error ?? new Error('IndexedDB transaction aborted'))
      })
      return values as T[]
    } finally {
      db.close()
    }
  }, storeName)
}
