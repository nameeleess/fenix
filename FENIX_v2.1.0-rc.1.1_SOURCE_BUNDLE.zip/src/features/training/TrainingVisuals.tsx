import { LicensedExerciseMotion } from './media/LicensedExerciseMotion'
import { useState } from 'react'
import type { Exercise } from '../../types/training'
import type { TrainingTemplateView } from './trainingService'
import { getExerciseMedia } from './media/exerciseMediaRegistry'

type MuscleZone =
  | 'chest'
  | 'shoulders'
  | 'arms'
  | 'back'
  | 'core'
  | 'glutes'
  | 'quads'
  | 'hamstrings'
  | 'calves'

function normalize(value: string) {
  return value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('es')
}

function zonesForMuscle(value: string): MuscleZone[] {
  const muscle = normalize(value)

  if (muscle.includes('pecho') || muscle.includes('pectoral')) return ['chest']
  if (muscle.includes('hombro') || muscle.includes('deltoid')) return ['shoulders']
  if (muscle.includes('bicep') || muscle.includes('tricep') || muscle.includes('brazo') || muscle.includes('antebrazo')) return ['arms']
  if (muscle.includes('espalda') || muscle.includes('dorsal') || muscle.includes('trapec')) return ['back']
  if (muscle.includes('core') || muscle.includes('abd')) return ['core']
  if (muscle.includes('glute')) return ['glutes']
  if (muscle.includes('cuadricep')) return ['quads']
  if (muscle.includes('isquio') || muscle.includes('femoral')) return ['hamstrings']
  if (muscle.includes('gemelo') || muscle.includes('pantorr')) return ['calves']
  if (muscle.includes('cadera')) return ['glutes', 'core']

  return []
}

function activeZones(muscles: string[]) {
  return new Set(muscles.flatMap(zonesForMuscle))
}

function Zone({
  zone,
  active,
  d,
}: {
  zone: MuscleZone
  active: Set<MuscleZone>
  d: string
}) {
  return <path className={active.has(zone) ? 'anatomy-zone is-active' : 'anatomy-zone'} d={d} />
}

function AnatomyFigure({
  active,
  back = false,
}: {
  active: Set<MuscleZone>
  back?: boolean
}) {
  return (
    <svg viewBox="0 0 94 178" aria-hidden="true">
      <circle className="anatomy-base" cx="47" cy="15" r="10" />
      <path className="anatomy-base" d="M36 28c-8 5-11 15-11 29l4 35 6 24 3 49h9l1-48h-2V90h2v27l1 48h9l3-49 6-24 4-35c0-14-3-24-11-29l-8-4H44l-8 4Z" />
      {!back ? (
        <>
          <Zone zone="shoulders" active={active} d="M35 31 24 41l4 17 12-8-1-17Zm24 0 11 10-4 17-12-8 1-17Z" />
          <Zone zone="chest" active={active} d="M39 34h16l5 17-13 8-13-8 5-17Z" />
          <Zone zone="arms" active={active} d="M25 45 19 70l6 22 7-2-3-25 5-20Zm44 0 6 25-6 22-7-2 3-25-5-20Z" />
          <Zone zone="core" active={active} d="M40 56h14l4 31-11 9-11-9 4-31Z" />
          <Zone zone="quads" active={active} d="M35 95 39 117l2 42h7l-1-42-1-22Zm24 0-4 22-2 42h-7l1-42 1-22Z" />
          <Zone zone="calves" active={active} d="M38 122 39 165h8l-1-43Zm18 0-1 43h-8l1-43Z" />
        </>
      ) : (
        <>
          <Zone zone="shoulders" active={active} d="M35 31 24 41l4 17 12-8-1-17Zm24 0 11 10-4 17-12-8 1-17Z" />
          <Zone zone="back" active={active} d="M38 34h18l8 19-6 31-11 8-11-8-6-31 8-19Z" />
          <Zone zone="arms" active={active} d="M25 45 19 70l6 22 7-2-3-25 5-20Zm44 0 6 25-6 22-7-2 3-25-5-20Z" />
          <Zone zone="glutes" active={active} d="M35 88c2 12 6 18 12 18s10-6 12-18l-12-5-12 5Z" />
          <Zone zone="hamstrings" active={active} d="M35 103 39 124l2 35h7l-1-42-1-14Zm24 0-4 21-2 35h-7l1-42 1-14Z" />
          <Zone zone="calves" active={active} d="M38 127 39 165h8l-1-38Zm18 0-1 38h-8l1-38Z" />
        </>
      )}
    </svg>
  )
}

export function RoutineMuscleMap({
  template,
  compact = false,
}: {
  template: TrainingTemplateView | null
  compact?: boolean
}) {
  const muscleCounts = new Map<string, number>()

  for (const item of template?.exercises ?? []) {
    const values = [item.exercise.primaryMuscle, ...item.exercise.secondaryMuscles]
    values.forEach((muscle, index) => {
      muscleCounts.set(
        muscle,
        (muscleCounts.get(muscle) ?? 0) + item.config.targetSets * (index === 0 ? 1 : 0.35),
      )
    })
  }

  const muscles = [...muscleCounts.entries()]
    .sort((first, second) => second[1] - first[1])
    .map(([muscle]) => muscle)

  const active = activeZones(muscles)

  return (
    <div className={compact ? 'training-anatomy training-anatomy--compact' : 'training-anatomy'}>
      <div className="training-anatomy__figures" aria-hidden="true">
        <AnatomyFigure active={active} />
        <AnatomyFigure active={active} back />
      </div>
      {!compact && (
        <div className="training-anatomy__copy">
          <span>MÚSCULOS HOY</span>
          <strong>{muscles.slice(0, 5).join(' · ') || 'Movilidad / recuperación'}</strong>
          <small>Mapa funcional de la sesión.</small>
        </div>
      )}
    </div>
  )
}

export function ExerciseMuscleMap({ exercise }: { exercise: Exercise }) {
  const muscles = [exercise.primaryMuscle, ...exercise.secondaryMuscles]
  const active = activeZones(muscles)

  return (
    <div className="training-exercise-anatomy" aria-label={`Músculos: ${muscles.join(', ')}`}>
      <AnatomyFigure active={active} />
    </div>
  )
}

export function ExerciseVisual({
  exercise,
  guided,
  interactive = false,
}: {
  exercise: Exercise
  guided: boolean
  interactive?: boolean
}) {
  const definition = getExerciseMedia(exercise.id)
  const [motion, setMotion] = useState(guided)
  const [paused, setPaused] = useState(false)
  const [failed, setFailed] = useState(false)

  return (
    <div className="training-exercise-visual training-exercise-visual--v21">
      <div className="training-exercise-visual__media">
        {definition && !motion && !failed ? (
          <picture>
            <img
              src={definition.staticAsset}
              alt={`Ilustración de ${exercise.name}`}
              loading="lazy"
              decoding="async"
              onError={(event) => {
                const candidates = [definition.staticAsset, ...(definition.fallbackAssets ?? (definition.fallbackAsset ? [definition.fallbackAsset] : []))]
                const current = candidates.findIndex(path => event.currentTarget.src.endsWith(path))
                if (current >= 0 && candidates[current + 1]) {
                  event.currentTarget.src = candidates[current + 1]
                } else {
                  setFailed(true)
                }
              }}
            />
          </picture>
        ) : null}
        {motion || !definition || failed ? <LicensedExerciseMotion key={exercise.id} exercise={exercise} paused={paused || !motion} /> : null}
        {definition?.source === 'user-licensed' ? <small className="training-exercise-visual__credit">Gymvisual</small> : definition?.source === 'repdb' ? (
          <small className="training-exercise-visual__credit">RepDB</small>
        ) : definition ? (
          <small className="training-exercise-visual__credit">FÉNIX</small>
        ) : null}
      </div>
      {interactive ? <div className="training-motion-controls">
        <button type="button" onClick={() => { setMotion(!motion); setPaused(false) }}>{motion ? 'Ver imagen' : 'Ver movimiento'}</button>
        {motion ? <button type="button" aria-pressed={paused} onClick={() => setPaused(!paused)}>{paused ? 'Reanudar movimiento' : 'Pausar movimiento'}</button> : null}
      </div> : null}
      <ExerciseMuscleMap exercise={exercise} />
    </div>
  )
}
