import {
  useEffect,
  useState,
} from 'react'

import type {
  Exercise,
  ExerciseSet,
  ExerciseTolerance,
  PlannedWorkoutSession,
  WorkoutSessionExercise,
} from '../../types/training'

import {
  addExerciseSet,
  discardEmptyWorkout,
  finishWorkout,
  getActiveWorkout,
  getExerciseAlternatives,
  getExerciseCatalog,
  getTrainingHome,
  getTrainingTemplates,
  getWorkoutHistory,
  omitPlannedWorkout,
  removeExerciseSet,
  reprogramPlannedWorkout,
  saveSetDraft,
  startPlannedWorkout,
  startRestTimer,
  startTemplateWorkout,
  stopRestTimer,
  substituteSessionExercise,
  toggleSetCompletion,
  updateExercisePersonalContext,
  createWorkoutTemplate,
  updateWorkoutTemplate,
  duplicateWorkoutTemplate,
  archiveWorkoutTemplate,
  createCustomExercise,
  updateCustomExercise,
  archiveCustomExercise,
  isSystemExercise,
  type WorkoutTemplateDraft,
  type WorkoutTemplateExerciseInput,
  type CustomExerciseDraft,
  type ActiveSessionView,
  type HistorySessionView,
  type SetValues,
  type TrainingHomeView,
  type TrainingTemplateView,
} from './trainingService'

import { AppHeader, ConfirmAction, Dialog, EmptyState, PrimaryButton, SecondaryButton, SegmentedTabs, Sheet, StatusBadge, WeekDaySelector } from '../../components/designSystem'
import { getLocalDateKey as getSharedLocalDateKey } from '../../utils/date'

import {
  ExerciseVisual,
  RoutineMuscleMap,
} from './TrainingVisuals'

import './training.css'

type TrainingTab =
  | 'home'
  | 'routines'
  | 'exercises'
  | 'history'

interface TrainingPageProps {
  isActive: boolean
  refreshRevision: number
  onOpenSettings: () => void
}

interface TrainingData {
  active: ActiveSessionView | null
  home: TrainingHomeView
  templates: TrainingTemplateView[]
  history: HistorySessionView[]
  exercises: Exercise[]
}

function formatDate(dateKey: string) {
  const [year, month, day] = dateKey.split('-').map(Number)

  return new Intl.DateTimeFormat('es-ES', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
  }).format(new Date(year, month - 1, day, 12))
}

function formatDateTime(value: string) {
  return new Intl.DateTimeFormat('es-ES', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(value))
}

function formatRest(seconds: number) {
  if (seconds <= 0) {
    return 'sin pausa fija'
  }

  const minutes = Math.floor(seconds / 60)
  const rest = seconds % 60

  return rest === 0
    ? `${minutes} min`
    : `${minutes}:${String(rest).padStart(2, '0')} min`
}

function statusLabel(status: PlannedWorkoutSession['status']) {
  if (status === 'pending') return 'Pendiente'
  if (status === 'in_progress') return 'En curso'
  if (status === 'completed') return 'Completada'
  if (status === 'incomplete') return 'Incompleta'
  return 'Omitida'
}

function statusClass(status: PlannedWorkoutSession['status']) {
  if (status === 'completed') return 'is-success'
  if (status === 'incomplete' || status === 'omitted') return 'is-danger'
  if (status === 'in_progress') return 'is-active'
  return 'is-pending'
}

function SetRow({
  set,
  targetRir,
  simpleText = null,
  onChanged,
  onCompleted,
}: {
  set: ExerciseSet
  targetRir: string
  simpleText?: string | null
  onChanged: () => Promise<void>
  onCompleted: (seconds: number) => Promise<void>
}) {
  const [weight, setWeight] = useState(set.weight?.toString() ?? '')
  const [reps, setReps] = useState(set.reps?.toString() ?? '')
  const [rir, setRir] = useState(set.rir?.toString() ?? '')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  function values(): SetValues {
    return {
      weight: weight.trim() === '' ? null : Number(weight),
      reps: reps.trim() === '' ? null : Number(reps),
      rir:
        set.setType === 'warmup' || rir.trim() === ''
          ? null
          : Number(rir),
    }
  }

  async function save() {
    try {
      await saveSetDraft(set.id, values())
      setError('')
    } catch (saveError: unknown) {
      setError(
        saveError instanceof Error
          ? saveError.message
          : 'No se ha podido guardar la serie.',
      )
    }
  }

  async function toggle() {
    setBusy(true)

    try {
      const result = await toggleSetCompletion(set.id, values())
      setError('')

      if (result.completed && result.restSeconds > 0) {
        await onCompleted(result.restSeconds)
      }

      await onChanged()
    } catch (toggleError: unknown) {
      setError(
        toggleError instanceof Error
          ? toggleError.message
          : 'No se ha podido actualizar la serie.',
      )
    } finally {
      setBusy(false)
    }
  }

  async function remove() {
    if (set.completedAt !== null) {
      setError('Desmarca la serie antes de eliminarla.')
      return
    }

    await removeExerciseSet(set.id)
    await onChanged()
  }

  return (
    <div
      className={`training-set-row ${set.completedAt ? 'is-completed' : ''} ${set.setType === 'warmup' ? 'is-warmup' : ''} ${simpleText ? 'is-simple' : ''}`}
    >
      <div className="training-set-row__index">
        <span>{set.setType === 'warmup' ? 'C' : set.order}</span>
        {set.setType === 'warmup' ? <small>calent.</small> : null}
      </div>

      {simpleText ? (
        <div className="training-set-row__simple">
          <span>OBJETIVO</span>
          <strong>{simpleText}</strong>
        </div>
      ) : (
        <>
          <label>
            <span>kg</span>
            <input
              type="number"
              inputMode="decimal"
              min="0"
              step="0.5"
              value={weight}
              onChange={(event) => setWeight(event.target.value)}
              onBlur={() => void save()}
            />
          </label>

          <label>
            <span>Reps</span>
            <input
              type="number"
              inputMode="numeric"
              min="0"
              step="1"
              value={reps}
              onChange={(event) => setReps(event.target.value)}
              onBlur={() => void save()}
            />
          </label>

          <label>
            <span>{set.setType === 'warmup' ? 'RIR —' : `RIR ${targetRir}`}</span>
            <input
              type="number"
              inputMode="decimal"
              min="0"
              max="10"
              step="0.5"
              value={set.setType === 'warmup' ? '' : rir}
              disabled={set.setType === 'warmup'}
              placeholder={set.setType === 'warmup' ? '—' : targetRir}
              onChange={(event) => setRir(event.target.value)}
              onBlur={() => void save()}
            />
          </label>
        </>
      )}

      <button
        type="button"
        className="training-set-row__complete"
        disabled={busy}
        aria-label={set.completedAt ? 'Desmarcar serie' : 'Completar serie'}
        onClick={() => void toggle()}
      >
        {set.completedAt ? '✓' : '○'}
      </button>

      <button
        type="button"
        className="training-set-row__remove"
        aria-label="Eliminar serie"
        onClick={() => void remove()}
      >
        ×
      </button>

      {error ? <p className="training-inline-error">{error}</p> : null}
    </div>
  )
}

function RestTimer({
  endsAt,
  onStop,
}: {
  endsAt: string | null
  onStop: () => Promise<void>
}) {
  const [clock, setClock] = useState(() => Date.now())

  useEffect(() => {
    if (!endsAt) {
      return undefined
    }

    const interval = window.setInterval(() => {
      setClock(Date.now())
    }, 1000)

    return () => window.clearInterval(interval)
  }, [endsAt])

  if (!endsAt) {
    return null
  }

  const remaining = Math.max(0, Math.ceil((Date.parse(endsAt) - clock) / 1000))
  const minutes = Math.floor(remaining / 60)
  const seconds = remaining % 60

  return (
    <div className={`training-rest-timer ${remaining === 0 ? 'is-done' : ''}`}>
      <div>
        <span>DESCANSO</span>
        <strong>{minutes}:{String(seconds).padStart(2, '0')}</strong>
      </div>
      <button type="button" onClick={() => void onStop()}>
        Omitir
      </button>
    </div>
  )
}

function ActiveTraining({
  view,
  onReload,
  onExit,
}: {
  view: ActiveSessionView
  onReload: () => Promise<void>
  onExit: () => void
}) {
  const [exerciseIndex, setExerciseIndex] = useState(0)
  const [finishOpen, setFinishOpen] = useState(false)
  const [substituteOpen, setSubstituteOpen] = useState(false)
  const [alternatives, setAlternatives] = useState<Exercise[]>([])
  const [selectedAlternative, setSelectedAlternative] = useState('')
  const [updateRoutine, setUpdateRoutine] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const boundedIndex = Math.min(
    exerciseIndex,
    Math.max(view.exercises.length - 1, 0),
  )
  const item = view.exercises[boundedIndex]

  async function completeSet(seconds: number) {
    if (seconds <= 0) {
      return
    }

    await startRestTimer(view.session.id, seconds)
  }

  async function stopTimer() {
    await stopRestTimer(view.session.id)
    await onReload()
  }

  async function openSubstitute(snapshot: WorkoutSessionExercise) {
    const options = await getExerciseAlternatives(snapshot)
    setAlternatives(options)
    setSelectedAlternative(options[0]?.id ?? '')
    setUpdateRoutine(false)
    setSubstituteOpen(true)
  }

  async function confirmSubstitution() {
    if (!item || selectedAlternative === '') {
      return
    }

    setBusy(true)

    try {
      await substituteSessionExercise(
        item.snapshot.id,
        selectedAlternative,
        updateRoutine,
      )
      setSubstituteOpen(false)
      setError('')
      await onReload()
    } catch (substitutionError: unknown) {
      setError(
        substitutionError instanceof Error
          ? substitutionError.message
          : 'No se ha podido sustituir el ejercicio.',
      )
    } finally {
      setBusy(false)
    }
  }

  async function finalize(result: 'completed' | 'incomplete') {
    setBusy(true)

    try {
      await finishWorkout(view.session.id, result)
      setFinishOpen(false)
      setError('')
      await onReload()
      onExit()
    } catch (finishError: unknown) {
      setError(
        finishError instanceof Error
          ? finishError.message
          : 'No se ha podido finalizar la sesión.',
      )
    } finally {
      setBusy(false)
    }
  }

  async function discard() {
    setBusy(true)

    try {
      await discardEmptyWorkout(view.session.id)
      setFinishOpen(false)
      setError('')
      await onReload()
      onExit()
    } catch (discardError: unknown) {
      setError(
        discardError instanceof Error
          ? discardError.message
          : 'No se ha podido descartar la sesión.',
      )
    } finally {
      setBusy(false)
    }
  }

  if (!item) {
    return (
      <main className="training-page">
        <p>No hay ejercicios disponibles en esta sesión.</p>
      </main>
    )
  }

  const targetRir =
    item.snapshot.targetRirMin === item.snapshot.targetRirMax
      ? `${item.snapshot.targetRirMin ?? '—'}`
      : `${item.snapshot.targetRirMin ?? '—'}–${item.snapshot.targetRirMax ?? '—'}`

  const previousText = item.previousSets.length > 0
    ? item.previousSets
        .map(
          (set) =>
            `${set.weight ?? '—'} kg × ${set.reps ?? '—'} · RIR ${set.rir ?? '—'}`,
        )
        .join(' · ')
    : 'Sin referencia comparable todavía.'

  const warmups = item.sets.filter((set) => set.setType === 'warmup')
  const working = item.sets.filter((set) => set.setType === 'working')
  const isGuidedSession = view.template.isFormalStrength === false
  const simpleTarget = item.snapshot.targetSeconds
    ? `${item.snapshot.targetSeconds} s`
    : `${item.snapshot.minReps}–${item.snapshot.maxReps} repeticiones`

  return (
    <main className="training-page training-page--active">
      <header className="training-active-header">
        <button type="button" className="training-back-button" onClick={onExit}>
          ‹
        </button>

        <div>
          <span className="training-kicker">TRAINING · EN CURSO</span>
          <h1>{view.template.name}</h1>
          <p>
            {view.completedWorkingSets}/{view.totalWorkingSets} {isGuidedSession ? 'pasos completados' : 'series de trabajo'} · iniciado {formatDateTime(view.session.startedAt)}
          </p>
        </div>

        <button
          type="button"
          className="training-finish-shortcut"
          onClick={() => setFinishOpen(true)}
        >
          Finalizar
        </button>
      </header>

      <RestTimer endsAt={view.restEndsAt} onStop={stopTimer} />

      <section className="training-current-card">
        <div className="training-current-card__top">
          <div>
            <span className="training-kicker">EJERCICIO {boundedIndex + 1} DE {view.exercises.length}</span>
            <h2>{item.exercise.name}</h2>
            <p>
              {isGuidedSession
                ? `${item.snapshot.targetSets} × ${simpleTarget}`
                : `${item.snapshot.targetSets} × ${item.snapshot.minReps}–${item.snapshot.maxReps} · RIR ${targetRir} · ${formatRest(item.snapshot.restSeconds)}`}
            </p>
          </div>

          <ExerciseVisual
            guided={isGuidedSession}
            interactive
            exercise={item.exercise}
          />
        </div>

        {!isGuidedSession ? (
          <div className="training-reference-grid">
            <div>
              <span>ÚLTIMA VEZ</span>
              <strong>{previousText}</strong>
            </div>
            <div>
              <span>SUGERENCIA</span>
              <strong>{item.progressionHint}</strong>
            </div>
          </div>
        ) : null}

        {item.exercise.techniqueNotes ? (
          <details className="training-technique-note training-technique-note--disclosure">
            <summary>
              <span>TÉCNICA</span>
              <b>Ver indicación</b>
            </summary>
            <p>{item.exercise.techniqueNotes}</p>
          </details>
        ) : null}

        {warmups.length > 0 ? (
          <div className="training-set-section">
            <div className="training-set-section__title">
              <span>CALENTAMIENTO ESPECÍFICO</span>
              <small>Auto-sugerido · editable · no cuenta como volumen de trabajo</small>
            </div>

            {warmups.map((set) => (
              <SetRow
                key={`${set.id}-${set.updatedAt}`}
                set={set}
                targetRir="—"
                onChanged={onReload}
                onCompleted={completeSet}
              />
            ))}
          </div>
        ) : null}

        <div className="training-set-section">
          <div className="training-set-section__title">
            <span>{isGuidedSession ? 'MOVIMIENTOS' : 'SERIES DE TRABAJO'}</span>
            <small>{isGuidedSession ? 'Completa cada paso con control.' : 'Peso · repeticiones · RIR real'}</small>
          </div>

          {working.map((set) => (
            <SetRow
              key={`${set.id}-${set.updatedAt}`}
              set={set}
              targetRir={targetRir}
              simpleText={isGuidedSession ? simpleTarget : null}
              onChanged={onReload}
              onCompleted={completeSet}
            />
          ))}

          {!isGuidedSession ? (
            <button
              type="button"
              className="training-secondary-button"
              onClick={async () => {
                await addExerciseSet(item.snapshot.id, 'working')
                await onReload()
              }}
            >
              + Añadir serie
            </button>
          ) : null}
        </div>

        <div className="training-current-actions">
          <button
            type="button"
            className="training-secondary-button"
            onClick={() => void openSubstitute(item.snapshot)}
          >
            Sustituir ejercicio
          </button>

          {boundedIndex > 0 ? (
            <button
              type="button"
              className="training-ghost-button"
              onClick={() => setExerciseIndex(boundedIndex - 1)}
            >
              ← Anterior
            </button>
          ) : null}

          {boundedIndex < view.exercises.length - 1 ? (
            <button
              type="button"
              className="training-primary-button"
              onClick={() => setExerciseIndex(boundedIndex + 1)}
            >
              Siguiente →
            </button>
          ) : (
            <button
              type="button"
              className="training-primary-button"
              onClick={() => setFinishOpen(true)}
            >
              Finalizar sesión
            </button>
          )}
        </div>
      </section>

      <section className="training-upcoming-card">
        <span className="training-kicker">SESIÓN</span>
        <div className="training-upcoming-list">
          {view.exercises.map((exerciseItem, index) => {
            const done = exerciseItem.sets.filter(
              (set) => set.setType === 'working' && set.completedAt !== null,
            ).length
            const total = exerciseItem.sets.filter(
              (set) => set.setType === 'working',
            ).length

            return (
              <button
                key={exerciseItem.snapshot.id}
                type="button"
                className={index === boundedIndex ? 'is-current' : ''}
                onClick={() => setExerciseIndex(index)}
              >
                <span>{index + 1}</span>
                <div>
                  <strong>{exerciseItem.exercise.name}</strong>
                  <small>{done}/{total} series · {exerciseItem.exercise.primaryMuscle}</small>
                </div>
                <b>{done === total && total > 0 ? '✓' : '›'}</b>
              </button>
            )
          })}
        </div>
      </section>

      {error ? <p className="training-page-error">{error}</p> : null}

      <Dialog
        open={finishOpen}
        title="¿Cómo termina esta sesión?"
        description="Training no finaliza automáticamente. Elige el resultado real para conservar el historial y la racha correctamente."
        onClose={() => setFinishOpen(false)}
      >
        <div className="training-dialog-actions-v21">
          <PrimaryButton type="button" disabled={busy} onClick={() => void finalize('completed')}>Marcar completada</PrimaryButton>
          <SecondaryButton type="button" disabled={busy} onClick={() => void finalize('incomplete')}>Finalizar incompleta</SecondaryButton>
          <button type="button" className="training-danger-button" disabled={busy} onClick={() => void discard()}>Descartar si fue accidental</button>
          <button type="button" className="training-ghost-button" onClick={() => setFinishOpen(false)}>Volver a la sesión</button>
        </div>
      </Dialog>

      <Dialog
        open={substituteOpen}
        title={`Sustituir · ${item.exercise.name}`}
        description="El cambio se aplica a esta sesión. Solo modifica la rutina si lo indicas expresamente."
        onClose={() => setSubstituteOpen(false)}
      >
        <label className="training-field">
          <span>Ejercicio alternativo</span>
          <select value={selectedAlternative} onChange={(event) => setSelectedAlternative(event.target.value)}>
            {alternatives.map((exercise) => (
              <option key={exercise.id} value={exercise.id}>{exercise.name} · {exercise.primaryMuscle}</option>
            ))}
          </select>
        </label>
        <label className="training-check-field">
          <input type="checkbox" checked={updateRoutine} onChange={(event) => setUpdateRoutine(event.target.checked)} />
          <span>Actualizar también la rutina futura</span>
        </label>
        <div className="ds-dialog__actions">
          <SecondaryButton type="button" onClick={() => setSubstituteOpen(false)}>Cancelar</SecondaryButton>
          <PrimaryButton type="button" disabled={busy || selectedAlternative === ''} onClick={() => void confirmSubstitution()}>Aplicar sustitución</PrimaryButton>
        </div>
      </Dialog>
    </main>
  )
}

function HomeView({
  home,
  templates,
  selectedDate,
  actualToday,
  onSelectDate,
  onStart,
  onStartTemplate,
  onReprogram,
  onOmit,
}: {
  home: TrainingHomeView
  templates: TrainingTemplateView[]
  selectedDate: string
  actualToday: string
  onSelectDate: (date: string) => void
  onStart: (session: PlannedWorkoutSession) => Promise<void>
  onStartTemplate: (templateId: string) => Promise<void>
  onReprogram: (session: PlannedWorkoutSession) => void
  onOmit: (session: PlannedWorkoutSession) => void
}) {
  const selectedDay = home.week.find((day) => day.date === selectedDate) ?? null
  const focus = selectedDate === actualToday
    ? home.focusSession
    : selectedDay?.sessions[0] ?? null
  const template = focus
    ? templates.find((item) => item.template.id === focus.workoutTemplateId) ?? null
    : null
  const multiSessionDays = home.week.filter((day) => day.sessions.length > 1)

  return (
    <>
      <WeekDaySelector
        actualToday={actualToday}
        selectedDate={selectedDate}
        onSelect={onSelectDate}
        days={home.week.map((day) => ({
          date: day.date,
          state: day.sessions.some((item) => item.status === 'in_progress')
            ? 'active'
            : day.sessions.some((item) => item.status === 'pending')
              ? 'pending'
              : day.sessions.some((item) => item.status === 'incomplete')
                ? 'incomplete'
                : day.sessions.some((item) => item.status === 'omitted')
                  ? 'omitted'
                  : day.sessions.length > 0 && day.sessions.every((item) => item.status === 'completed')
                    ? 'completed'
                    : 'idle',
          badge: day.sessions.length > 1 ? day.sessions.length : null,
        }))}
      />

      {selectedDate !== actualToday ? (
        <div className="training-selected-day-context">
          <span className="training-kicker">FECHA CONSULTADA</span>
          <strong>{formatDate(selectedDate)}</strong>
          <small>Hoy real sigue siendo {formatDate(actualToday)}; racha y pendientes no se reinterpretan.</small>
        </div>
      ) : null}

      {multiSessionDays.length > 0 ? (
        <section className="training-same-day-panel">
          <div className="training-section-heading">
            <div>
              <span className="training-kicker">MÚLTIPLES SESIONES</span>
              <h2>Sesiones que comparten fecha</h2>
            </div>
          </div>

          <div className="training-same-day-list">
            {multiSessionDays.flatMap((day) =>
              day.sessions.map((session) => (
                <article key={session.id} className="training-same-day-session">
                  <div>
                    <span>{formatDate(day.date)}</span>
                    <strong>{session.templateName}</strong>
                    <small className={statusClass(session.status)}>{statusLabel(session.status)}</small>
                  </div>
                  <div className="training-same-day-actions">
                    {(session.status === 'pending' || session.status === 'in_progress') ? (
                      <button type="button" onClick={() => void onStart(session)}>
                        {session.status === 'in_progress' ? 'Reabrir' : 'Iniciar'}
                      </button>
                    ) : null}
                    {session.status === 'pending' ? (
                      <>
                        <button type="button" onClick={() => onReprogram(session)}>Reprogramar</button>
                        <button type="button" onClick={() => onOmit(session)}>Omitir</button>
                      </>
                    ) : null}
                  </div>
                </article>
              )),
            )}
          </div>
        </section>
      ) : null}

      {home.actionableSessions.length > 1 ? (
        <section className="training-session-queue">
          <div className="training-section-heading">
            <div>
              <span className="training-kicker">AGENDA PENDIENTE</span>
              <h2>Otras sesiones disponibles</h2>
            </div>
          </div>

          <div className="training-session-queue__list">
            {home.actionableSessions.slice(1).map((session) => (
              <article key={session.id} className="training-session-queue__item">
                <div>
                  <span>{formatDate(session.scheduledDate)}</span>
                  <strong>{session.templateName}</strong>
                  <small>{statusLabel(session.status)}</small>
                </div>
                <div className="training-same-day-actions">
                  {(session.status === 'pending' || session.status === 'in_progress') ? (
                    <button type="button" onClick={() => void onStart(session)}>
                      {session.status === 'in_progress' ? 'Reabrir' : 'Iniciar'}
                    </button>
                  ) : null}
                  {session.status === 'pending' ? (
                    <>
                      <button type="button" onClick={() => onReprogram(session)}>Reprogramar</button>
                      <button type="button" onClick={() => onOmit(session)}>Omitir</button>
                    </>
                  ) : null}
                </div>
              </article>
            ))}
          </div>
        </section>
      ) : null}

      {home.unresolvedPast > 0 ? (
        <div className="training-attention-banner">
          <strong>{home.unresolvedPast} sesión pendiente de resolver</strong>
          <span>No se ha marcado como omitida automáticamente.</span>
        </div>
      ) : null}

      {focus && template ? (
        <section className="training-session-hero">
          <div className="training-session-hero__header">
            <div>
              <span className="training-kicker">
                {focus.scheduledDate < actualToday
                  ? 'PENDIENTE ANTERIOR'
                  : focus.scheduledDate === actualToday
                    ? 'HOY'
                    : 'PRÓXIMA SESIÓN'}
              </span>
              <h2>{focus.templateName}</h2>
              <p>
                {formatDate(focus.scheduledDate)} · {focus.estimatedDurationMinutes ?? '—'} min estimados · {template.totalSets} series de trabajo
              </p>
            </div>
            <span className={`training-status-pill ${statusClass(focus.status)}`}>
              {statusLabel(focus.status)}
            </span>
          </div>

          <div className="training-session-overview">
          <div className="training-session-preview">
            <span className="training-kicker">EJERCICIOS DESTACADOS</span>
            {template.exercises.slice(0, 4).map((item, index) => (
              <div key={item.config.id}>
                <span>{index + 1}</span>
                <div>
                  <strong>{item.exercise.name}</strong>
                  <small>
                    {item.config.targetSets} × {item.config.minReps}–{item.config.maxReps} · RIR {item.config.targetRirMin ?? item.config.targetRir ?? '—'}{item.config.targetRirMax && item.config.targetRirMax !== item.config.targetRirMin ? `–${item.config.targetRirMax}` : ''}
                  </small>
                </div>
              </div>
            ))}
            {template.exercises.length > 4 && (
              <p className="training-session-preview__more">
                + {template.exercises.length - 4} ejercicios más al iniciar la sesión
              </p>
            )}
          </div>
          <RoutineMuscleMap template={template} compact />
          </div>

          {(focus.status === 'pending' || focus.status === 'in_progress') ? (
            <button
              type="button"
              className="training-primary-button"
              onClick={() => void onStart(focus)}
            >
              {focus.status === 'in_progress' ? 'Reabrir' : 'Iniciar'} {focus.templateName}
            </button>
          ) : null}

          {focus.status === 'pending' ? (
            <div className="training-inline-actions">
              <button type="button" onClick={() => onReprogram(focus)}>Reprogramar</button>
              <button type="button" onClick={() => onOmit(focus)}>Omitir sesión</button>
            </div>
          ) : null}
        </section>
      ) : (
        <section className="training-empty-card">
          <span className="training-kicker">TRAINING</span>
          <h2>No hay sesión formal pendiente.</h2>
          <p>La programación futura se genera localmente a partir de tus rutinas aprobadas.</p>
        </section>
      )}

      <section className="training-home-grid">
        <article className="training-mini-card">
          <span>SEMANA</span>
          <strong>{home.completedThisWeek}/{home.plannedThisWeek}</strong>
          <small>sesiones formales completadas</small>
        </article>
        <article className="training-mini-card">
          <span>RACHA</span>
          <strong>{home.streakPending ? `${home.streak} · ?` : home.streak}</strong>
          <small>{home.streakPending ? 'pendiente de confirmar' : 'sesiones consecutivas'}</small>
        </article>
      </section>

      <section className="training-secondary-programs">
        <div className="training-section-heading">
          <div>
            <span className="training-kicker">MOVILIDAD & RECOVERY</span>
            <h2>Trabajo complementario</h2>
          </div>
        </div>

        <div className="training-secondary-programs__grid">
          {home.mobilityTemplate ? (
            <article>
              <span>DIARIA · 5–8 MIN</span>
              <h3>{home.mobilityTemplate.template.name}</h3>
              <p>{home.mobilityTemplate.template.description}</p>
              <button
                type="button"
                onClick={() => void onStartTemplate(home.mobilityTemplate!.template.id)}
              >
                Abrir movilidad
              </button>
            </article>
          ) : null}

          {home.recoveryTemplate ? (
            <article>
              <span>MIÉRCOLES · 15–20 MIN</span>
              <h3>{home.recoveryTemplate.template.name}</h3>
              <p>{home.recoveryTemplate.template.description}</p>
              <button
                type="button"
                onClick={() => void onStartTemplate(home.recoveryTemplate!.template.id)}
              >
                Abrir recovery
              </button>
            </article>
          ) : null}
        </div>
      </section>
    </>
  )
}

type RoutineEditorItem = WorkoutTemplateExerciseInput & { clientKey: string }
type RoutineEditorDraft = Omit<WorkoutTemplateDraft, 'exercises'> & { exercises: RoutineEditorItem[] }

function draftFromTemplate(view: TrainingTemplateView): RoutineEditorDraft {
  return {
    name: view.template.name,
    dayOfWeek: view.template.dayOfWeek,
    type: view.template.type,
    description: view.template.description,
    estimatedDurationMinutes: view.template.estimatedDurationMinutes ?? null,
    isFormalStrength: view.template.isFormalStrength ?? false,
    exercises: view.exercises.map(({ config }) => ({
      id: config.id,
      clientKey: config.id,
      exerciseId: config.exerciseId,
      order: config.order,
      targetSets: config.targetSets,
      minReps: config.minReps,
      maxReps: config.maxReps,
      targetRirMin: config.targetRirMin ?? config.targetRir ?? null,
      targetRirMax: config.targetRirMax ?? config.targetRir ?? null,
      restSeconds: config.restSeconds,
      referenceWeight: config.referenceWeight,
      alternativeExerciseIds: config.alternativeExerciseIds ?? [],
      supersetGroupId: config.supersetGroupId ?? null,
      targetSeconds: config.targetSeconds ?? null,
    })),
  }
}

function emptyRoutineDraft(): RoutineEditorDraft {
  return {
    name: '',
    dayOfWeek: null,
    type: 'upper',
    description: null,
    estimatedDurationMinutes: 50,
    isFormalStrength: true,
    exercises: [],
  }
}

function RoutinesView({
  templates,
  exercises,
  onReload,
  onStartTemplate,
  starting,
}: {
  templates: TrainingTemplateView[]
  exercises: Exercise[]
  onReload: () => Promise<void>
  onStartTemplate: (templateId: string) => Promise<void>
  starting: boolean
}) {
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [editingId, setEditingId] = useState<string | 'new' | null>(null)
  const [draft, setDraft] = useState<ReturnType<typeof emptyRoutineDraft>>(emptyRoutineDraft())
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [archiveId, setArchiveId] = useState<string | null>(null)
  const formal = templates.filter((item) => item.template.isFormalStrength)
  const selected = formal.find((item) => item.template.id === selectedId) ?? null

  function openNew() {
    setDraft(emptyRoutineDraft())
    setEditingId('new')
    setError('')
  }

  function openEdit(view: TrainingTemplateView) {
    setDraft(draftFromTemplate(view))
    setEditingId(view.template.id)
    setError('')
  }

  function patchExercise(clientKey: string, patch: Partial<RoutineEditorItem>) {
    setDraft((current) => ({
      ...current,
      exercises: current.exercises.map((item) => item.clientKey === clientKey ? { ...item, ...patch } : item),
    }))
  }

  function reorder(clientKey: string, direction: -1 | 1) {
    setDraft((current) => {
      const items = [...current.exercises].sort((a, b) => a.order - b.order)
      const index = items.findIndex((item) => item.clientKey === clientKey)
      const target = index + direction
      if (index < 0 || target < 0 || target >= items.length) return current
      ;[items[index], items[target]] = [items[target], items[index]]
      return { ...current, exercises: items.map((item, itemIndex) => ({ ...item, order: (itemIndex + 1) * 10 })) }
    })
  }

  function addExercise() {
    const first = exercises[0]
    if (!first) return
    setDraft((current) => ({
      ...current,
      exercises: [...current.exercises, {
        clientKey: crypto.randomUUID(),
        exerciseId: first.id,
        order: (current.exercises.length + 1) * 10,
        targetSets: 3,
        minReps: 6,
        maxReps: 10,
        targetRirMin: 1,
        targetRirMax: 2,
        restSeconds: 120,
        referenceWeight: null,
        alternativeExerciseIds: [],
        supersetGroupId: null,
        targetSeconds: null,
      }],
    }))
  }

  async function save() {
    setBusy(true); setError('')
    try {
      const input: WorkoutTemplateDraft = {
        ...draft,
        exercises: draft.exercises.map((item, index) => ({
          ...(item.id ? { id: item.id } : {}),
          exerciseId: item.exerciseId,
          order: (index + 1) * 10,
          targetSets: Number(item.targetSets),
          minReps: Number(item.minReps),
          maxReps: Number(item.maxReps),
          targetRirMin: item.targetRirMin === null ? null : Number(item.targetRirMin),
          targetRirMax: item.targetRirMax === null ? null : Number(item.targetRirMax),
          restSeconds: Number(item.restSeconds),
          referenceWeight: item.referenceWeight ?? null,
          alternativeExerciseIds: item.alternativeExerciseIds ?? [],
          supersetGroupId: item.supersetGroupId ?? null,
          targetSeconds: item.targetSeconds ?? null,
        })),
      }
      if (editingId === 'new') await createWorkoutTemplate(input)
      else if (editingId) await updateWorkoutTemplate(editingId, input)
      setEditingId(null)
      await onReload()
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : 'No se ha podido guardar la rutina.')
    } finally { setBusy(false) }
  }

  async function duplicate(id: string) {
    setBusy(true); setError('')
    try { await duplicateWorkoutTemplate(id); await onReload() }
    catch (duplicateError) { setError(duplicateError instanceof Error ? duplicateError.message : 'No se ha podido duplicar.') }
    finally { setBusy(false) }
  }

  async function archive() {
    if (!archiveId) return
    setBusy(true); setError('')
    try { await archiveWorkoutTemplate(archiveId); setArchiveId(null); await onReload() }
    catch (archiveError) { setError(archiveError instanceof Error ? archiveError.message : 'No se ha podido archivar.') }
    finally { setBusy(false) }
  }

  return (
    <div className="training-routines-screen">
      <div className="training-section-heading training-section-heading--action">
        <div><span className="training-kicker">RUTINAS</span><h2>Tu programación</h2><p>Los cambios afectan a futuras sesiones; el historial permanece intacto.</p></div>
        <PrimaryButton type="button" onClick={openNew}>Crear rutina</PrimaryButton>
      </div>
      {error ? <p className="training-page-error" role="alert">{error}</p> : null}
      {formal.length === 0 ? <EmptyState title="Sin rutinas" description="Crea tu primera rutina formal." action={<PrimaryButton onClick={openNew}>Crear rutina</PrimaryButton>} /> : null}
      <div className="training-routines-grid">
        {formal.map((view) => (
          <section key={view.template.id} className="training-routine-card training-routine-card--summary">
            <div className="training-routine-card__header">
              <div><span className="training-kicker">RUTINA</span><h2>{view.template.name}</h2><p>{view.template.description}</p></div>
              <strong>{view.totalSets} series</strong>
            </div>
            <RoutineMuscleMap template={view} compact />
            <div className="training-routine-summary-list">
              {view.exercises.slice(0, 5).map((item) => <span key={item.config.id}>{item.exercise.name}<small>{item.config.targetSets}×{item.config.minReps}–{item.config.maxReps}</small></span>)}
            </div>
            <div className="training-inline-actions">
              <button type="button" onClick={() => setSelectedId(view.template.id)}>Ver detalle</button>
              <button type="button" onClick={() => openEdit(view)}>Editar</button>
              <button type="button" onClick={() => void duplicate(view.template.id)} disabled={busy}>Duplicar</button>
              <button type="button" onClick={() => setArchiveId(view.template.id)} disabled={busy}>Archivar</button>
            </div>
          </section>
        ))}
      </div>

      <Sheet
        open={selected !== null}
        title={selected?.template.name ?? 'Detalle de rutina'}
        subtitle="Training · detalle de rutina"
        onClose={() => setSelectedId(null)}
      >
        {selected ? (
          <div className="training-routine-detail-v21">
            <section className="training-routine-detail-v21__hero">
              <div>
                <span className="training-kicker">RUTINA</span>
                <h2>{selected.template.name}</h2>
                <p>{selected.template.description || 'Rutina de Training preparada para futuras sesiones.'}</p>
                <div className="training-routine-detail-v21__meta">
                  <StatusBadge tone="accent">{selected.template.estimatedDurationMinutes ?? '—'} min</StatusBadge>
                  <StatusBadge>{selected.exercises.length} ejercicios</StatusBadge>
                  <StatusBadge>{selected.totalSets} series</StatusBadge>
                </div>
              </div>
              <RoutineMuscleMap template={selected} />
            </section>

            <section className="training-routine-detail-v21__section">
              <header><span className="training-kicker">EJERCICIOS ({selected.exercises.length})</span><strong>Prescripción</strong></header>
              <div className="training-routine-detail-v21__list">
                {selected.exercises.map((item, index) => (
                  <article key={item.config.id} className="training-routine-detail-v21__exercise">
                    <span className="training-routine-detail-v21__order">{index + 1}</span>
                    <div className="training-routine-detail-v21__exercise-visual">
                      <ExerciseVisual exercise={item.exercise} guided={false} />
                    </div>
                    <div>
                      <strong>{item.exercise.name}</strong>
                      <span>{item.config.targetSets}×{item.config.minReps}–{item.config.maxReps} · RIR {item.config.targetRirMin ?? item.config.targetRir ?? '—'}{item.config.targetRirMax !== null && item.config.targetRirMax !== undefined ? `–${item.config.targetRirMax}` : ''}</span>
                      <small>{formatRest(item.config.restSeconds)}{item.config.supersetGroupId ? ` · Superset ${item.config.supersetGroupId}` : ''}</small>
                    </div>
                  </article>
                ))}
              </div>
            </section>

            <div className="training-routine-detail-v21__actions">
              <PrimaryButton
                type="button"
                disabled={starting}
                onClick={() => {
                  const id = selected.template.id
                  setSelectedId(null)
                  void onStartTemplate(id)
                }}
              >
                {starting ? 'Iniciando…' : 'Iniciar rutina'}
              </PrimaryButton>
              <SecondaryButton
                type="button"
                onClick={() => {
                  const view = selected
                  setSelectedId(null)
                  openEdit(view)
                }}
              >Editar rutina</SecondaryButton>
            </div>
          </div>
        ) : null}
      </Sheet>

      <Sheet open={editingId !== null} title={editingId === 'new' ? 'Crear rutina' : 'Editar rutina'} subtitle="Training · futuras sesiones" onClose={() => setEditingId(null)}>
        <div className="training-routine-editor-v21">
          <label className="training-field"><span>Nombre</span><input value={draft.name} onChange={(event) => setDraft((current) => ({ ...current, name: event.target.value }))} /></label>
          <div className="training-editor-grid">
            <label className="training-field"><span>Tipo</span><select value={draft.type} onChange={(event) => setDraft((current) => ({ ...current, type: event.target.value as WorkoutTemplateDraft['type'] }))}><option value="upper">Upper</option><option value="lower">Lower</option><option value="core">Core</option><option value="mobility">Movilidad</option><option value="recovery">Recovery</option></select></label>
            <label className="training-field"><span>Día</span><select value={draft.dayOfWeek ?? ''} onChange={(event) => setDraft((current) => ({ ...current, dayOfWeek: event.target.value === '' ? null : Number(event.target.value) }))}><option value="">Flexible</option><option value="1">Lunes</option><option value="2">Martes</option><option value="3">Miércoles</option><option value="4">Jueves</option><option value="5">Viernes</option><option value="6">Sábado</option><option value="0">Domingo</option></select></label>
            <label className="training-field"><span>Duración estimada</span><input type="number" min="1" value={draft.estimatedDurationMinutes ?? ''} onChange={(event) => setDraft((current) => ({ ...current, estimatedDurationMinutes: event.target.value === '' ? null : Number(event.target.value) }))} /></label>
          </div>
          <label className="training-field"><span>Notas</span><textarea value={draft.description ?? ''} onChange={(event) => setDraft((current) => ({ ...current, description: event.target.value || null }))} /></label>
          <button type="button" className="training-unavailable-action" disabled data-central-exception="CENTRAL-EXCEPTION-G10-ROUTINE-EXPORT-01">Exportar rutina <small>No disponible</small></button>

          <div className="training-routine-editor-v21__heading"><div><span className="training-kicker">EJERCICIOS</span><h3>Orden y prescripción</h3></div><SecondaryButton type="button" onClick={addExercise}>+ Ejercicio</SecondaryButton></div>
          {draft.exercises.map((item, index) => (
            <article className="training-routine-editor-row" key={item.clientKey}>
              <div className="training-routine-editor-row__top">
                <strong>{index + 1}</strong>
                <select value={item.exerciseId} onChange={(event) => patchExercise(item.clientKey, { exerciseId: event.target.value })}>{exercises.map((exercise) => <option key={exercise.id} value={exercise.id}>{exercise.name}</option>)}</select>
                <button type="button" disabled={index === 0} onClick={() => reorder(item.clientKey, -1)}>↑</button>
                <button type="button" disabled={index === draft.exercises.length - 1} onClick={() => reorder(item.clientKey, 1)}>↓</button>
                <button type="button" aria-label="Retirar ejercicio" onClick={() => setDraft((current) => ({ ...current, exercises: current.exercises.filter((candidate) => candidate.clientKey !== item.clientKey) }))}>×</button>
              </div>
              <div className="training-editor-grid training-editor-grid--sets">
                <label><span>Series</span><input type="number" min="1" value={item.targetSets} onChange={(event) => patchExercise(item.clientKey, { targetSets: Number(event.target.value) })} /></label>
                <label><span>Rep min</span><input type="number" min="1" value={item.minReps} onChange={(event) => patchExercise(item.clientKey, { minReps: Number(event.target.value) })} /></label>
                <label><span>Rep max</span><input type="number" min="1" value={item.maxReps} onChange={(event) => patchExercise(item.clientKey, { maxReps: Number(event.target.value) })} /></label>
                <label><span>RIR min</span><input type="number" value={item.targetRirMin ?? ''} onChange={(event) => patchExercise(item.clientKey, { targetRirMin: event.target.value === '' ? null : Number(event.target.value) })} /></label>
                <label><span>RIR max</span><input type="number" value={item.targetRirMax ?? ''} onChange={(event) => patchExercise(item.clientKey, { targetRirMax: event.target.value === '' ? null : Number(event.target.value) })} /></label>
                <label><span>Descanso s</span><input type="number" min="0" value={item.restSeconds} onChange={(event) => patchExercise(item.clientKey, { restSeconds: Number(event.target.value) })} /></label>
              </div>
              <div className="training-editor-grid">
                <label className="training-field"><span>Superset</span><input placeholder="Ej. A" value={item.supersetGroupId ?? ''} onChange={(event) => patchExercise(item.clientKey, { supersetGroupId: event.target.value || null })} /></label>
                <label className="training-field"><span>Alternativa</span><select value={item.alternativeExerciseIds?.[0] ?? ''} onChange={(event) => patchExercise(item.clientKey, { alternativeExerciseIds: event.target.value ? [event.target.value] : [] })}><option value="">Sin alternativa</option>{exercises.filter((exercise) => exercise.id !== item.exerciseId).map((exercise) => <option key={exercise.id} value={exercise.id}>{exercise.name}</option>)}</select></label>
              </div>
            </article>
          ))}
          {error ? <p className="training-page-error" role="alert">{error}</p> : null}
          <div className="ds-dialog__actions"><SecondaryButton type="button" onClick={() => setEditingId(null)}>Cancelar</SecondaryButton><PrimaryButton type="button" disabled={busy} onClick={() => void save()}>{busy ? 'Guardando…' : 'Guardar rutina'}</PrimaryButton></div>
        </div>
      </Sheet>

      <ConfirmAction open={archiveId !== null} title="Archivar rutina" description="La rutina dejará de estar disponible para nuevas sesiones. Las ejecuciones históricas no se modifican." confirmLabel="Archivar" busy={busy} onCancel={() => setArchiveId(null)} onConfirm={archive} />
    </div>
  )
}

function emptyExerciseDraft(): CustomExerciseDraft {
  return {
    name: '',
    primaryMuscle: '',
    secondaryMuscles: [],
    equipment: '',
    exerciseType: 'isolation',
    tolerance: null,
    personalNotes: null,
    techniqueNotes: null,
    mediaPath: null,
    mediaType: null,
  }
}

function ExercisesView({
  exercises,
  onReload,
}: {
  exercises: Exercise[]
  onReload: () => Promise<void>
}) {
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState('all')
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [editingId, setEditingId] = useState<string | 'new' | null>(null)
  const [draft, setDraft] = useState<CustomExerciseDraft>(emptyExerciseDraft())
  const [tolerance, setTolerance] = useState<ExerciseTolerance | ''>('')
  const [personalNotes, setPersonalNotes] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [archiveId, setArchiveId] = useState<string | null>(null)

  const muscles = [...new Set(exercises.map((item) => item.primaryMuscle))].sort((a, b) => a.localeCompare(b, 'es'))
  const normalizedQuery = query.trim().toLocaleLowerCase('es')
  const filtered = exercises.filter((exercise) => {
    const matchesQuery = !normalizedQuery || [exercise.name, exercise.primaryMuscle, exercise.equipment]
      .some((value) => value.toLocaleLowerCase('es').includes(normalizedQuery))
    const matchesFilter = filter === 'all' || exercise.primaryMuscle === filter
    return matchesQuery && matchesFilter
  })
  const selected = exercises.find((item) => item.id === selectedId) ?? null

  function openDetail(exercise: Exercise) {
    setSelectedId(exercise.id)
    setTolerance(exercise.tolerance ?? '')
    setPersonalNotes(exercise.personalNotes ?? '')
    setError('')
  }

  function openCreate() {
    setDraft(emptyExerciseDraft())
    setEditingId('new')
    setError('')
  }

  function openEdit(exercise: Exercise) {
    setDraft({
      name: exercise.name,
      primaryMuscle: exercise.primaryMuscle,
      secondaryMuscles: exercise.secondaryMuscles,
      equipment: exercise.equipment,
      exerciseType: exercise.exerciseType,
      tolerance: exercise.tolerance ?? null,
      personalNotes: exercise.personalNotes ?? null,
      techniqueNotes: exercise.techniqueNotes,
      mediaPath: exercise.mediaPath,
      mediaType: exercise.mediaType,
    })
    setEditingId(exercise.id)
    setError('')
  }

  async function saveContext() {
    if (!selected) return
    setBusy(true); setError('')
    try {
      await updateExercisePersonalContext(selected.id, {
        tolerance: tolerance === '' ? null : tolerance,
        personalNotes: personalNotes.trim() || null,
      })
      await onReload()
      setSelectedId(selected.id)
    } catch (saveError) { setError(saveError instanceof Error ? saveError.message : 'No se ha podido guardar.') }
    finally { setBusy(false) }
  }

  async function saveCustom() {
    setBusy(true); setError('')
    try {
      if (editingId === 'new') await createCustomExercise(draft)
      else if (editingId) await updateCustomExercise(editingId, draft)
      setEditingId(null)
      await onReload()
    } catch (saveError) { setError(saveError instanceof Error ? saveError.message : 'No se ha podido guardar el ejercicio.') }
    finally { setBusy(false) }
  }

  async function archiveCustom() {
    if (!archiveId) return
    setBusy(true); setError('')
    try { await archiveCustomExercise(archiveId); setArchiveId(null); setSelectedId(null); await onReload() }
    catch (archiveError) { setError(archiveError instanceof Error ? archiveError.message : 'No se ha podido archivar.') }
    finally { setBusy(false) }
  }

  return (
    <div className="training-exercises-screen">
      <div className="training-section-heading training-section-heading--action">
        <div><span className="training-kicker">CATÁLOGO</span><h2>Ejercicios</h2><p>Busca, revisa técnica y mantén tus ejercicios propios separados del sistema.</p></div>
        <PrimaryButton type="button" onClick={openCreate}>Crear ejercicio</PrimaryButton>
      </div>
      <div className="training-catalog-tools">
        <input type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar ejercicio…" aria-label="Buscar ejercicio" />
        <select value={filter} onChange={(event) => setFilter(event.target.value)} aria-label="Filtrar por músculo"><option value="all">Todos</option>{muscles.map((muscle) => <option key={muscle} value={muscle}>{muscle}</option>)}</select>
      </div>
      {error ? <p className="training-page-error" role="alert">{error}</p> : null}
      <div className="training-exercise-catalog training-exercise-catalog--grid">
        {filtered.map((exercise) => (
          <button key={exercise.id} type="button" className="training-catalog-card training-catalog-card--button" onClick={() => openDetail(exercise)}>
            <ExerciseVisual exercise={exercise} guided={false} />
            <div className="training-catalog-card__heading"><div><span>{exercise.primaryMuscle}</span><h3>{exercise.name}</h3><p>{exercise.equipment}</p></div><StatusBadge tone={isSystemExercise(exercise) ? 'neutral' : 'accent'}>{isSystemExercise(exercise) ? 'Sistema' : 'Propio'}</StatusBadge></div>
          </button>
        ))}
      </div>
      {filtered.length === 0 ? <EmptyState title="Sin resultados" description="Prueba otra búsqueda o crea un ejercicio propio." /> : null}

      <Sheet open={selected !== null} title={selected?.name ?? 'Ejercicio'} subtitle={selected ? `${selected.primaryMuscle} · ${selected.equipment}` : undefined} onClose={() => setSelectedId(null)}>
        {selected ? <div className="training-exercise-detail-v21">
          <ExerciseVisual key={selected.id} exercise={selected} guided={false} interactive />
          <div className="training-exercise-detail-v21__meta"><StatusBadge tone={isSystemExercise(selected) ? 'neutral' : 'accent'}>{isSystemExercise(selected) ? 'Ejercicio del sistema' : 'Ejercicio propio'}</StatusBadge><span>{selected.exerciseType}</span></div>
          {selected.techniqueNotes ? <section><span className="training-kicker">TÉCNICA</span><p>{selected.techniqueNotes}</p></section> : null}
          <label className="training-field"><span>Tolerancia personal</span><select value={tolerance} onChange={(event) => setTolerance(event.target.value as ExerciseTolerance | '')}><option value="">Sin registrar</option><option value="no_issues">Sin problemas</option><option value="occasional_discomfort">Molestia ocasional</option><option value="avoid_for_now">Evitar por ahora</option></select></label>
          <label className="training-field"><span>Notas personales</span><textarea value={personalNotes} onChange={(event) => setPersonalNotes(event.target.value)} /></label>
          <PrimaryButton type="button" disabled={busy} onClick={() => void saveContext()}>Guardar contexto</PrimaryButton>
          {!isSystemExercise(selected) ? <div className="training-inline-actions"><button type="button" onClick={() => { setSelectedId(null); openEdit(selected) }}>Editar ejercicio</button><button type="button" onClick={() => setArchiveId(selected.id)}>Archivar</button></div> : null}
        </div> : null}
      </Sheet>

      <Sheet open={editingId !== null} title={editingId === 'new' ? 'Crear ejercicio' : 'Editar ejercicio'} subtitle="Ejercicio propio" onClose={() => setEditingId(null)}>
        <div className="training-custom-exercise-editor">
          <label className="training-field"><span>Nombre</span><input value={draft.name} onChange={(event) => setDraft((current) => ({ ...current, name: event.target.value }))} /></label>
          <div className="training-editor-grid">
            <label className="training-field"><span>Músculo principal</span><input value={draft.primaryMuscle} onChange={(event) => setDraft((current) => ({ ...current, primaryMuscle: event.target.value }))} /></label>
            <label className="training-field"><span>Secundarios</span><input value={draft.secondaryMuscles.join(', ')} onChange={(event) => setDraft((current) => ({ ...current, secondaryMuscles: event.target.value.split(',').map((item) => item.trim()).filter(Boolean) }))} /></label>
            <label className="training-field"><span>Equipamiento</span><input value={draft.equipment} onChange={(event) => setDraft((current) => ({ ...current, equipment: event.target.value }))} /></label>
            <label className="training-field"><span>Patrón</span><select value={draft.exerciseType} onChange={(event) => setDraft((current) => ({ ...current, exerciseType: event.target.value as CustomExerciseDraft['exerciseType'] }))}><option value="compound">Compuesto</option><option value="isolation">Aislamiento</option><option value="core">Core</option><option value="mobility">Movilidad</option></select></label>
          </div>
          <div className="training-unavailable-actions" data-central-exception="CENTRAL-EXCEPTION-G11-EXERCISE-ACTIONS-01">
            <button type="button" disabled>Apto para calentamiento<small>No disponible</small></button>
            <span>Ejercicio propio</span>
            <button type="button" disabled>Marcar como favorito<small>No disponible</small></button>
          </div>
          <label className="training-field"><span>Técnica / cues</span><textarea value={draft.techniqueNotes ?? ''} onChange={(event) => setDraft((current) => ({ ...current, techniqueNotes: event.target.value || null }))} /></label>
          <label className="training-field"><span>Notas personales</span><textarea value={draft.personalNotes ?? ''} onChange={(event) => setDraft((current) => ({ ...current, personalNotes: event.target.value || null }))} /></label>
          <label className="training-field"><span>Media propia (ruta local opcional)</span><input value={draft.mediaPath ?? ''} placeholder="/media/..." onChange={(event) => setDraft((current) => ({ ...current, mediaPath: event.target.value || null, mediaType: event.target.value ? 'image' : null }))} /></label>
          {error ? <p className="training-page-error" role="alert">{error}</p> : null}
          <div className="ds-dialog__actions"><SecondaryButton type="button" onClick={() => setEditingId(null)}>Cancelar</SecondaryButton><PrimaryButton type="button" disabled={busy} onClick={() => void saveCustom()}>{busy ? 'Guardando…' : 'Guardar ejercicio'}</PrimaryButton></div>
        </div>
      </Sheet>

      <ConfirmAction open={archiveId !== null} title="Archivar ejercicio" description="El ejercicio dejará de estar disponible para nuevas rutinas. El historial no se modifica." confirmLabel="Archivar" busy={busy} onCancel={() => setArchiveId(null)} onConfirm={archiveCustom} />
    </div>
  )
}

function HistoryView({
  history,
}: {
  history: HistorySessionView[]
}) {
  if (history.length === 0) {
    return (
      <section className="training-empty-card">
        <span className="training-kicker">HISTORIAL</span>
        <h2>Aún no hay sesiones finalizadas.</h2>
        <p>Las sesiones canceladas legacy se conservan en la base, pero no se presentan como entrenamiento realizado.</p>
      </section>
    )
  }

  return (
    <>
    <section className="training-history-summary" aria-label="Resumen del historial">
      <div><strong>{history.length}</strong><span>sesiones totales</span></div>
      <div><strong>{(() => {
        const durations = history.flatMap(item => {
          const end = item.session.endedAt ?? item.session.completedAt
          if (!end) return []
          const minutes = (Date.parse(end) - Date.parse(item.session.startedAt)) / 60000
          return Number.isFinite(minutes) && minutes >= 0 ? [minutes] : []
        })
        return durations.length ? `${Math.round(durations.reduce((sum, value) => sum + value, 0) / durations.length)} min` : '—'
      })()}</strong><span>duración promedio</span></div>
      <div data-central-exception="CENTRAL-EXCEPTION-G06-TRAINING-VOLUME-KPI-01"><strong>—</strong><span>Métrica no disponible</span></div>
    </section>
    <h2 className="training-history-heading">Historial de sesiones</h2>
    <div className="training-history-list">
      {history.map((item) => {
        const workingSets = item.sets.filter((set) => set.setType === 'working')

        return (
          <details key={item.session.id} className="training-history-card">
            <summary>
            <div>
              <span className="training-kicker">
                {item.session.status === 'completed' ? 'COMPLETADA' : 'INCOMPLETA'}
              </span>
              <h3>{item.session.templateName}</h3>
              <p>{formatDateTime(item.session.endedAt ?? item.session.completedAt ?? item.session.startedAt)}</p>
            </div>
            <strong>{workingSets.length} series registradas</strong>
            </summary>
            <div className="training-history-exercises">
              {item.exercises.map((exercise) => {
                const exerciseSets = workingSets.filter(
                  (set) => set.workoutSessionExerciseId === exercise.id,
                )

                return (
                  <div key={exercise.id}>
                    <span>{exercise.exerciseName}</span>
                    <small>
                      {exerciseSets.length > 0
                        ? exerciseSets
                            .map((set) => `${set.weight ?? '—'}×${set.reps ?? '—'}`)
                            .join(' · ')
                        : 'sin series completadas'}
                    </small>
                  </div>
                )
              })}
            </div>
          </details>
        )
      })}
    </div>
    </>
  )
}

async function fetchTrainingData(): Promise<TrainingData> {
  const [active, home, templates, history, exercises] = await Promise.all([
    getActiveWorkout(),
    getTrainingHome(),
    getTrainingTemplates(),
    getWorkoutHistory(),
    getExerciseCatalog(),
  ])

  return {
    active,
    home,
    templates,
    history: history.sessions,
    exercises,
  }
}

export default function TrainingPage({
  isActive,
  refreshRevision,
  onOpenSettings,
}: TrainingPageProps) {
  const [tab, setTab] = useState<TrainingTab>('home')
  const [data, setData] = useState<TrainingData | null>(null)
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [activeVisible, setActiveVisible] = useState(true)
  const [reprogramSession, setReprogramSession] = useState<PlannedWorkoutSession | null>(null)
  const [reprogramDate, setReprogramDate] = useState('')
  const [omitSession, setOmitSession] = useState<PlannedWorkoutSession | null>(null)
  const actualToday = getSharedLocalDateKey()
  const [selectedDate, setSelectedDate] = useState(actualToday)


  async function reload() {
    const next = await fetchTrainingData()
    setData(next)
  }

  useEffect(() => {
    if (!isActive) return

    let active = true

    const timer = window.setTimeout(() => {
      setLoading(true)

      void fetchTrainingData()
        .then((next) => {
          if (!active) return
          setData(next)
          setError('')
          setLoading(false)
        })
        .catch((loadError: unknown) => {
          if (!active) return
          setError(
            loadError instanceof Error
              ? loadError.message
              : 'No se ha podido cargar Training.',
          )
          setLoading(false)
        })
    }, 0)

    return () => {
      active = false
      window.clearTimeout(timer)
    }
  }, [isActive, refreshRevision])

  const activeSessionId = data?.active?.session.id ?? null

  useEffect(() => {
    if (!isActive || activeSessionId === null || !activeVisible) return
    type WakeLockSentinelLike = { release: () => Promise<void> }
    type NavigatorWithWakeLock = Navigator & { wakeLock?: { request: (type: 'screen') => Promise<WakeLockSentinelLike> } }
    const wakeLock = (navigator as NavigatorWithWakeLock).wakeLock
    if (!wakeLock) return
    let sentinel: WakeLockSentinelLike | null = null
    let cancelled = false

    const acquire = async () => {
      if (document.visibilityState !== 'visible' || cancelled || sentinel) return
      try { sentinel = await wakeLock.request('screen') } catch { /* feature can be denied without breaking Training */ }
    }
    const visibility = () => {
      if (document.visibilityState === 'visible') void acquire()
      else if (sentinel) { void sentinel.release(); sentinel = null }
    }
    void acquire()
    document.addEventListener('visibilitychange', visibility)
    return () => {
      cancelled = true
      document.removeEventListener('visibilitychange', visibility)
      if (sentinel) void sentinel.release()
    }
  }, [isActive, activeSessionId, activeVisible])

  async function startPlanned(session: PlannedWorkoutSession) {
    if (data?.active) {
      setActiveVisible(true)
      return
    }

    setBusy(true)

    try {
      await startPlannedWorkout(session.id)
      setError('')
      setActiveVisible(true)
      await reload()
    } catch (startError: unknown) {
      setError(
        startError instanceof Error ? startError.message : 'No se ha podido iniciar la sesión.',
      )
    } finally {
      setBusy(false)
    }
  }

  async function startTemplate(templateId: string) {
    if (data?.active) {
      setActiveVisible(true)
      return
    }

    setBusy(true)

    try {
      await startTemplateWorkout(templateId)
      setActiveVisible(true)
      setError('')
      await reload()
    } catch (startError: unknown) {
      setError(
        startError instanceof Error ? startError.message : 'No se ha podido iniciar la rutina.',
      )
    } finally {
      setBusy(false)
    }
  }

  async function confirmReprogram() {
    if (!reprogramSession || reprogramDate === '') return

    setBusy(true)

    try {
      await reprogramPlannedWorkout(reprogramSession.id, reprogramDate)
      setReprogramSession(null)
      setReprogramDate('')
      setError('')
      await reload()
    } catch (reprogramError: unknown) {
      setError(
        reprogramError instanceof Error
          ? reprogramError.message
          : 'No se ha podido reprogramar.',
      )
    } finally {
      setBusy(false)
    }
  }

  async function confirmOmit() {
    if (!omitSession) return

    setBusy(true)

    try {
      await omitPlannedWorkout(omitSession.id)
      setOmitSession(null)
      setError('')
      await reload()
    } catch (omitError: unknown) {
      setError(
        omitError instanceof Error ? omitError.message : 'No se ha podido omitir la sesión.',
      )
    } finally {
      setBusy(false)
    }
  }

  if (loading || !data) {
    return (
      <main className="training-page training-loading">
        <p>Preparando Training…</p>
      </main>
    )
  }

  if (data.active && activeVisible) {
    return (
      <ActiveTraining
        view={data.active}
        onReload={reload}
        onExit={() => setActiveVisible(false)}
      />
    )
  }

  return (
    <main className="training-page">
      <AppHeader
        title="Training"
        dateKey={actualToday}
        onSettings={onOpenSettings}
        action={data.active ? (
          <button type="button" className="training-resume-button" onClick={() => setActiveVisible(true)}>Retomar sesión</button>
        ) : null}
      />

      <SegmentedTabs<TrainingTab>
        value={tab}
        label="Secciones de Training"
        onChange={setTab}
        items={[
          { value: 'home', label: 'Hoy' },
          { value: 'routines', label: 'Rutinas' },
          { value: 'exercises', label: 'Ejercicios' },
          { value: 'history', label: 'Historial' },
        ]}
      />

      {error ? <p className="training-page-error">{error}</p> : null}

      {tab === 'home' ? (
        <HomeView
          home={data.home}
          templates={data.templates}
          selectedDate={selectedDate}
          actualToday={actualToday}
          onSelectDate={setSelectedDate}
          onStart={startPlanned}
          onStartTemplate={startTemplate}
          onReprogram={(session) => {
            setReprogramSession(session)
            setReprogramDate(session.scheduledDate)
          }}
          onOmit={setOmitSession}
        />
      ) : null}

      {tab === 'routines' ? (
        <RoutinesView templates={data.templates} exercises={data.exercises} onReload={reload} onStartTemplate={startTemplate} starting={busy} />
      ) : null}

      {tab === 'exercises' ? (
        <ExercisesView exercises={data.exercises} onReload={reload} />
      ) : null}

      {tab === 'history' ? (
        <HistoryView history={data.history} />
      ) : null}

      {busy ? <div className="training-busy-toast">Guardando…</div> : null}

      <Dialog
        open={reprogramSession !== null}
        title={reprogramSession ? `Reprogramar · ${reprogramSession.templateName}` : 'Reprogramar sesión'}
        description="La identidad de la sesión se conserva. Nutrition mantiene asociados sus bloques Pre/Post pendientes."
        onClose={() => setReprogramSession(null)}
      >
        <label className="training-field">
          <span>Nueva fecha</span>
          <input type="date" value={reprogramDate} onChange={(event) => setReprogramDate(event.target.value)} />
        </label>
        <div className="ds-dialog__actions">
          <SecondaryButton type="button" onClick={() => setReprogramSession(null)}>Cancelar</SecondaryButton>
          <PrimaryButton type="button" disabled={busy || reprogramDate === ''} onClick={() => void confirmReprogram()}>Guardar fecha</PrimaryButton>
        </div>
      </Dialog>

      <ConfirmAction
        open={omitSession !== null}
        title={omitSession ? `Omitir · ${omitSession.templateName}` : 'Omitir sesión'}
        description="La omisión será explícita y romperá la racha de sesiones formales. No se aplica automáticamente a días sin registro."
        confirmLabel="Confirmar omisión"
        busy={busy}
        onCancel={() => setOmitSession(null)}
        onConfirm={confirmOmit}
      />
    </main>
  )
}
