const paths: Record<string, string> = {
  routine: 'M12 3v2m0 14v2M3 12h2m14 0h2M5.6 5.6 7 7m10 10 1.4 1.4M5.6 18.4 7 17M17 7l1.4-1.4M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
  training: 'M6 8v8M18 8v8M3 10v4m18-4v4M6 12h12',
  nutrition: 'M6 3v7m-3-7v5a3 3 0 0 0 6 0V3M6 11v10M16 3c3 3 3 5 3 9h-3V3m3 9v9',
  progress: 'M5 20V12m7 8V4m7 16V8',
  data: 'M4 6c0-4 16-4 16 0s-16 4-16 0m0 0v12c0 4 16 4 16 0V6M4 12c0 4 16 4 16 0',
  notifications: 'M5 17h14l-2-3V9a5 5 0 0 0-10 0v5l-2 3m5 3h4',
  pwa: 'M3 8a14 14 0 0 1 18 0M6 12a9 9 0 0 1 12 0m-9 4a4 4 0 0 1 6 0m-3 4h.01',
  credits: 'M12 10v7m0-11v.01M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0',
  body: 'M8 3h8l1 5 4 12-7 1-2-5-2 5-7-1L7 8Z',
  weight: 'M5 6h14v15H5ZM9 6V3h6v3m-3 1v3',
  target: 'M19 10a8 8 0 1 1-5-5m-2 3a4 4 0 1 0 4 4M12 12 21 3m-4 0h4v4',
}

export function SectionIcon({ name }: { name: string }) {
  return <svg className="ds-section-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name] ?? paths.target}/></svg>
}
